package com.ssafy.trip.board.photo.model.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PhotoMapper {

}
