package com.ssafy.trip.board.photo.model.service;

public interface PhotoService {

}
