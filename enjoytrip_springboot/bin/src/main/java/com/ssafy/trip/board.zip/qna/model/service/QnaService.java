package com.ssafy.trip.board.qna.model.service;

public interface QnaService {

}
