package com.ssafy.trip.board.qna.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/board/qna")
@CrossOrigin("*")
@RestController
public class QnaController {

}
