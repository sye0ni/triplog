package com.ssafy.trip.board.qna.model.service;

import org.springframework.stereotype.Service;

@Service
public class QnaServiceImpl implements QnaService{

}
