package com.ssafy.trip.board.photo.model.service;

import org.springframework.stereotype.Service;

@Service
public class PhotoServiceImpl implements PhotoService{

}
